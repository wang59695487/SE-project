drop table if exists stock_data;
drop table if exists stock_index;
drop table if exists stock_industries;